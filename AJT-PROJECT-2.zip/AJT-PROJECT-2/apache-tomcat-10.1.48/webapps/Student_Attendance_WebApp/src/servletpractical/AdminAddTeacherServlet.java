package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import dbutil.DBConnection;

public class AdminAddTeacherServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        resp.setHeader("Cache-Control", "no-store");
        PrintWriter out = resp.getWriter();

        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String pass = req.getParameter("pass");
        String dept = req.getParameter("dept");

        if (name == null || email == null || pass == null ||
                name.isBlank() || email.isBlank() || pass.isBlank()) {
            out.print("{\"ok\":false,\"msg\":\"Missing fields\"}");
            return;
        }

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "INSERT INTO teacher(name,email,password,department) VALUES(?,?,?,?)",
                     Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, pass);     // simple for project
            ps.setString(4, dept);

            int rows = ps.executeUpdate();
            if (rows > 0) {
                ResultSet keys = ps.getGeneratedKeys();
                int id = keys.next() ? keys.getInt(1) : 0;
                out.print("{\"ok\":true,\"id\":"+id+"}");
            } else {
                out.print("{\"ok\":false,\"msg\":\"Insert failed\"}");
            }
        } catch (SQLException e) {
            out.print("{\"ok\":false,\"msg\":\""+e.getMessage().replace("\"","\\\"")+"\"}");
        }
    }
}