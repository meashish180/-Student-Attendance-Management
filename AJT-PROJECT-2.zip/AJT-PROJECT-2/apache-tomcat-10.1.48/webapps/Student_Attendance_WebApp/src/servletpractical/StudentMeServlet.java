package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import dbutil.DBConnection;

public class StudentMeServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setHeader("Cache-Control", "no-store");

        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("roll_no") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.println("{\"error\":\"Not logged in\"}");
            return;
        }

        String rollNo = (String) session.getAttribute("roll_no");

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT s.student_id, s.name, s.roll_no, c.class_id, c.class_name " +
                             "FROM student s JOIN classroom c ON s.class_id = c.class_id " +
                             "WHERE s.roll_no = ?")) {

            ps.setString(1, rollNo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    out.println("{");
                    out.println("\"studentId\": " + rs.getInt("student_id") + ",");
                    out.println("\"name\": \"" + escape(rs.getString("name")) + "\",");
                    out.println("\"roll\": \"" + escape(rs.getString("roll_no")) + "\",");
                    out.println("\"classId\": \"" + rs.getInt("class_id") + "\",");
                    out.println("\"className\": \"" + escape(rs.getString("class_name")) + "\"");
                    out.println("}");
                } else {
                    out.println("{\"error\":\"Student not found\"}");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            out.println("{\"error\":\"Database error\"}");
        }
    }

    private String escape(String s) {
        return s == null ? "" : s.replace("\"", "\\\"");
    }
}