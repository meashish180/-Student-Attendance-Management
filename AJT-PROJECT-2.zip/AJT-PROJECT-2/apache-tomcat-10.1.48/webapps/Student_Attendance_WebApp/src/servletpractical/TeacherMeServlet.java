package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;

public class TeacherMeServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        HttpSession ses = req.getSession(false);
        if (ses == null || !"teacher".equals(ses.getAttribute("role"))) {
            resp.setStatus(401);
            out.print("{\"unauthorized\":true}");
            return;
        }
        out.print("{\"id\":"+ses.getAttribute("teacherId")+","
                + "\"name\":\""+esc((String)ses.getAttribute("teacherName"))+"\","
                + "\"email\":\""+esc((String)ses.getAttribute("teacherEmail"))+"\"}");
    }
    private String esc(String s){ return s==null?"":s.replace("\\","\\\\").replace("\"","\\\""); }
}