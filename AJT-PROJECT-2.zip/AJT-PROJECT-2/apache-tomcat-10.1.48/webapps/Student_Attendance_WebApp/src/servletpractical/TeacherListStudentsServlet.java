package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import dbutil.DBConnection;

public class TeacherListStudentsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        resp.setHeader("Cache-Control", "no-store");
        PrintWriter out = resp.getWriter();

        HttpSession ses = req.getSession(false);
        if (ses == null || !"teacher".equals(ses.getAttribute("role"))) {
            resp.setStatus(401);
            out.print("{\"unauthorized\":true}");
            return;
        }
        int teacherId = (int) ses.getAttribute("teacherId");

        String q = req.getParameter("q");
        boolean hasQ = q != null && !q.isBlank();

        String sqlBase =
                "SELECT s.student_id AS id, s.name, s.roll_no AS roll, c.class_name AS className " +
                        "FROM student s JOIN classroom c ON s.class_id = c.class_id " +
                        "WHERE c.teacher_id = ? ";
        String sqlAll = sqlBase + "ORDER BY c.class_name, s.roll_no";
        String sqlQ   = sqlBase + "AND (s.name LIKE ? OR s.roll_no LIKE ? OR c.class_name LIKE ?) " +
                "ORDER BY c.class_name, s.roll_no";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(hasQ ? sqlQ : sqlAll)) {

            ps.setInt(1, teacherId);
            if (hasQ) {
                String like = "%" + q.trim() + "%";
                ps.setString(2, like);
                ps.setString(3, like);
                ps.setString(4, like);
            }
            ResultSet rs = ps.executeQuery();

            StringBuilder sb = new StringBuilder();
            sb.append("[");
            boolean first = true;
            while (rs.next()) {
                if (!first) sb.append(",");
                sb.append("{");
                sb.append("\"id\":").append(rs.getInt("id")).append(",");
                sb.append("\"name\":\"").append(esc(rs.getString("name"))).append("\",");
                sb.append("\"roll\":\"").append(esc(rs.getString("roll"))).append("\",");
                sb.append("\"className\":\"").append(esc(rs.getString("className"))).append("\"");
                sb.append("}");
                first = false;
            }
            sb.append("]");
            out.print(sb.toString());
        } catch (SQLException e) {
            out.print("{\"error\":\""+esc(e.getMessage())+"\"}");
        }
    }

    private String esc(String s){ return s==null ? "" : s.replace("\\","\\\\").replace("\"","\\\""); }
}