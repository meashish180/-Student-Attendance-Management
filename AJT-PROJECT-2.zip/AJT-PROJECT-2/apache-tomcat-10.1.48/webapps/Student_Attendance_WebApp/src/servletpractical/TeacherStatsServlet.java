package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import dbutil.DBConnection;

public class TeacherStatsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        resp.setHeader("Cache-Control", "no-store");
        PrintWriter out = resp.getWriter();

        HttpSession ses = req.getSession(false);
        if (ses == null || !"teacher".equals(ses.getAttribute("role"))) {
            resp.setStatus(401); out.print("{\"unauthorized\":true}"); return;
        }
        int teacherId = (int) ses.getAttribute("teacherId");

        int classesCnt = 0, studentsCnt = 0;
        int pToday = 0, tToday = 0;
        Map<Integer, Double> monthlyMap = new HashMap<>(); // month(1-12) -> pct

        try (Connection con = DBConnection.getConnection()) {
            // 1) classes count
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT COUNT(*) FROM classroom WHERE teacher_id=?")) {
                ps.setInt(1, teacherId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) classesCnt = rs.getInt(1);
            }

            // 2) students across teacher's classes
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT COUNT(*) FROM student WHERE class_id IN (SELECT class_id FROM classroom WHERE teacher_id=?)")) {
                ps.setInt(1, teacherId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) studentsCnt = rs.getInt(1);
            }

            // 3) today's present/total (attendance joined to subjects in teacher's classes)
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT SUM(CASE WHEN a.status='P' THEN 1 ELSE 0 END) AS p, COUNT(*) AS t " +
                            "FROM attendance a JOIN subject s ON a.subject_id=s.subject_id " +
                            "WHERE s.class_id IN (SELECT class_id FROM classroom WHERE teacher_id=?) " +
                            "AND a.date = CURDATE()")) {
                ps.setInt(1, teacherId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) { pToday = rs.getInt("p"); tToday = rs.getInt("t"); }
            }

            // 4) monthly trend for current year
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT MONTH(a.date) AS m, " +
                            "ROUND(SUM(CASE WHEN a.status='P' THEN 1 ELSE 0 END)/COUNT(*)*100,2) AS pct " +
                            "FROM attendance a JOIN subject s ON a.subject_id=s.subject_id " +
                            "WHERE s.class_id IN (SELECT class_id FROM classroom WHERE teacher_id=?) " +
                            "AND YEAR(a.date)=YEAR(CURDATE()) " +
                            "GROUP BY MONTH(a.date)")) {
                ps.setInt(1, teacherId);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) monthlyMap.put(rs.getInt("m"), rs.getDouble("pct"));
            }

        } catch (SQLException e) {
            out.print("{\"error\":\"" + esc(e.getMessage()) + "\"}");
            return;
        }

        // Build months array (Jan..Dec)
        String[] monNames = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        sb.append("\"classes\":").append(classesCnt).append(",");
        sb.append("\"students\":").append(studentsCnt).append(",");
        sb.append("\"today\":{");
        sb.append("\"present\":").append(pToday).append(",");
        sb.append("\"total\":").append(tToday).append(",");
        double pct = (tToday>0)? Math.round((pToday*10000.0/tToday))/100.0 : 0.0;
        sb.append("\"percent\":").append(pct).append("},");
        sb.append("\"months\":[");
        for (int i=0;i<12;i++){ if(i>0) sb.append(","); sb.append("\"").append(monNames[i]).append("\""); }
        sb.append("],\"monthlyPct\":[");
        for (int i=1;i<=12;i++){ if(i>1) sb.append(","); sb.append(monthlyMap.getOrDefault(i, 0.0)); }
        sb.append("]}");

        out.print(sb.toString());
    }

    private String esc(String s){ return s==null ? "" : s.replace("\\","\\\\").replace("\"","\\\""); }
}