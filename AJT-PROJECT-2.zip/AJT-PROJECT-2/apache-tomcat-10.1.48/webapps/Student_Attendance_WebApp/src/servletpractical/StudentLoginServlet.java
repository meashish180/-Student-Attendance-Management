package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import dbutil.DBConnection;

public class StudentLoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        String rollNo = request.getParameter("roll_no");
        String password = request.getParameter("password");

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT student_id, name FROM student WHERE roll_no=? AND password=?")) {

            ps.setString(1, rollNo);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    HttpSession session = request.getSession();
                    session.setAttribute("roll_no", rollNo);
                    session.setAttribute("student_id", rs.getInt("student_id"));
                    session.setAttribute("name", rs.getString("name"));
                    response.sendRedirect("student_dashboard.html");
                } else {
                    response.getWriter().println("<script>alert('Invalid credentials');location='student_login.html';</script>");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("<script>alert('Database error');location='student_login.html';</script>");
        }
    }
}