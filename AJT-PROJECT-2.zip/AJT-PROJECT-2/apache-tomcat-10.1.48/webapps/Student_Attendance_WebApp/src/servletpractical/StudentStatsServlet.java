package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import dbutil.DBConnection;

public class StudentStatsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setHeader("Cache-Control", "no-store");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("student_id") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.println("{\"error\":\"Not logged in\"}");
            return;
        }

        int studentId = (int) session.getAttribute("student_id");

        try (Connection con = DBConnection.getConnection()) {

            int subjects = 0;
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT COUNT(*) FROM subject WHERE class_id = " +
                            "(SELECT class_id FROM student WHERE student_id = ?)")) {
                ps.setInt(1, studentId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) subjects = rs.getInt(1);
                }
            }

            int present = 0, total = 0;
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT SUM(status='P') AS present, COUNT(*) AS total " +
                            "FROM attendance WHERE student_id = ?")) {
                ps.setInt(1, studentId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        present = rs.getInt("present");
                        total = rs.getInt("total");
                    }
                }
            }
            double overallPct = (total > 0) ? (present * 100.0 / total) : 0;

            int tPresent = 0, tTotal = 0;
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT SUM(status='P') AS present, COUNT(*) AS total " +
                            "FROM attendance WHERE student_id = ? AND date = CURDATE()")) {
                ps.setInt(1, studentId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        tPresent = rs.getInt("present");
                        tTotal = rs.getInt("total");
                    }
                }
            }
            double todayPct = (tTotal > 0) ? (tPresent * 100.0 / tTotal) : 0;

            // Monthly statistics (strict‑mode friendly)
            StringBuilder monthsJson = new StringBuilder("[");
            StringBuilder pctJson = new StringBuilder("[");

            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT DATE_FORMAT(MIN(a.date),'%b') AS month, " +
                            "YEAR(a.date) AS yr, MONTH(a.date) AS mon, " +
                            "SUM(a.status='P') AS present, COUNT(*) AS total " +
                            "FROM attendance a " +
                            "WHERE a.student_id = ? " +
                            "GROUP BY YEAR(a.date), MONTH(a.date) " +
                            "ORDER BY yr, mon")) {

                ps.setInt(1, studentId);
                try (ResultSet rs = ps.executeQuery()) {
                    boolean first = true;
                    while (rs.next()) {
                        if (!first) { monthsJson.append(","); pctJson.append(","); }
                        first = false;
                        String month = rs.getString("month");
                        int p = rs.getInt("present");
                        int t = rs.getInt("total");
                        double pct = (t > 0) ? (p * 100.0 / t) : 0.0;
                        monthsJson.append("\"").append(month).append("\"");
                        pctJson.append(String.format("%.2f", pct));
                    }
                }
            }
            monthsJson.append("]");
            pctJson.append("]");

            out.println("{");
            out.println("\"subjects\": " + subjects + ",");
            out.println("\"overall\": {\"present\": " + present + ", \"total\": " + total +
                    ", \"percent\": " + String.format("%.2f", overallPct) + "},");
            out.println("\"today\": {\"present\": " + tPresent + ", \"total\": " + tTotal +
                    ", \"percent\": " + String.format("%.2f", todayPct) + "},");
            out.println("\"months\": " + monthsJson + ",");
            out.println("\"monthlyPct\": " + pctJson);
            out.println("}");

        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.println("{\"error\":\"Database error: " + escape(e.getMessage()) + "\"}");
        }
    }

    private String escape(String s) {
        return s == null ? "" : s.replace("\"", "\\\"");
    }
}