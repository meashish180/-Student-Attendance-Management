package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import dbutil.DBConnection;

public class StudentRecentServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setHeader("Cache-Control", "no-store");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("student_id") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("{\"error\":\"Not logged in\"}");
            return;
        }

        int studentId = (int) session.getAttribute("student_id");

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT a.date, a.status, s.subject_name " +
                             "FROM attendance a " +
                             "JOIN subject s ON a.subject_id = s.subject_id " +
                             "WHERE a.student_id = ? " +
                             "ORDER BY a.date DESC LIMIT 10")) {

            ps.setInt(1, studentId);

            try (ResultSet rs = ps.executeQuery()) {
                StringBuilder json = new StringBuilder("[");
                boolean first = true;
                while (rs.next()) {
                    if (!first) json.append(",");
                    first = false;
                    String date = rs.getString("date");
                    String status = rs.getString("status");
                    String subject = rs.getString("subject_name");

                    json.append("{")
                            .append("\"date\":\"").append(date).append("\",")
                            .append("\"subject\":\"").append(escape(subject)).append("\",")
                            .append("\"status\":\"").append(status).append("\"")
                            .append("}");
                }
                json.append("]");
                out.print(json);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\":\"Database error: " + escape(e.getMessage()) + "\"}");
        }
    }

    private String escape(String s) {
        return s == null ? "" : s.replace("\"", "\\\"");
    }
}