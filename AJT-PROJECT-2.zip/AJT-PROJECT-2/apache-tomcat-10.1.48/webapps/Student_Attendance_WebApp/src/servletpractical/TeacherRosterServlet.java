package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import dbutil.DBConnection;

public class TeacherRosterServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        HttpSession ses = req.getSession(false);
        if (ses == null || !"teacher".equals(ses.getAttribute("role"))) {
            resp.setStatus(401);
            out.print("{\"unauthorized\":true}");
            return;
        }

        String classId = req.getParameter("classId");
        if (classId == null || classId.isBlank()) { out.print("[]"); return; }

        String sql = "SELECT student_id AS id, name, roll_no AS roll FROM student WHERE class_id=? ORDER BY roll_no";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, Integer.parseInt(classId));
            ResultSet rs = ps.executeQuery();
            StringBuilder sb = new StringBuilder("[");
            boolean first=true;
            while (rs.next()) {
                if(!first) sb.append(",");
                sb.append("{\"id\":").append(rs.getInt("id"))
                        .append(",\"name\":\"").append(esc(rs.getString("name"))).append("\"")
                        .append(",\"roll\":\"").append(esc(rs.getString("roll"))).append("\"}");
                first=false;
            }
            sb.append("]");
            out.print(sb.toString());
        } catch (SQLException e) {
            out.print("{\"error\":\""+esc(e.getMessage())+"\"}");
        }
    }
    private String esc(String s){ return s==null? "" : s.replace("\"","\\\""); }
}