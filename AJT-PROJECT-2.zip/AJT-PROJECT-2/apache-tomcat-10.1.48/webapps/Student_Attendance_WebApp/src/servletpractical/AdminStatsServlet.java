package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import dbutil.DBConnection;

public class AdminStatsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        resp.setHeader("Cache-Control", "no-store");
        PrintWriter out = resp.getWriter();

        int students = 0, teachers = 0, classesCnt = 0;
        int pToday = 0, tToday = 0;
        Map<Integer, Double> monthly = new HashMap<>(); // month(1..12) -> pct

        try (Connection con = DBConnection.getConnection()) {
            // counts
            students = singleInt(con, "SELECT COUNT(*) FROM student");
            teachers = singleInt(con, "SELECT COUNT(*) FROM teacher");
            classesCnt = singleInt(con, "SELECT COUNT(*) FROM classroom");

            // today's attendance (all classes)
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT SUM(CASE WHEN status='P' THEN 1 ELSE 0 END) AS p, COUNT(*) AS t " +
                            "FROM attendance WHERE date = CURDATE()")) {
                ResultSet rs = ps.executeQuery();
                if (rs.next()) { pToday = rs.getInt("p"); tToday = rs.getInt("t"); }
            }

            // monthly trend (current year, all classes)
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT MONTH(date) AS m, " +
                            "ROUND(SUM(CASE WHEN status='P' THEN 1 ELSE 0 END)/COUNT(*)*100,2) AS pct " +
                            "FROM attendance WHERE YEAR(date)=YEAR(CURDATE()) " +
                            "GROUP BY MONTH(date)")) {
                ResultSet rs = ps.executeQuery();
                while (rs.next()) monthly.put(rs.getInt("m"), rs.getDouble("pct"));
            }
        } catch (SQLException e) {
            out.print("{\"error\":\"" + esc(e.getMessage()) + "\"}");
            return;
        }

        String[] names = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        sb.append("\"students\":").append(students).append(",");
        sb.append("\"teachers\":").append(teachers).append(",");
        sb.append("\"classes\":").append(classesCnt).append(",");
        double pctToday = (tToday>0)? Math.round((pToday*10000.0/tToday))/100.0 : 0.0;
        sb.append("\"today\":{")
                .append("\"present\":").append(pToday).append(",")
                .append("\"total\":").append(tToday).append(",")
                .append("\"percent\":").append(pctToday).append("},");
        sb.append("\"months\":[");
        for (int i=0;i<12;i++){ if(i>0) sb.append(","); sb.append("\"").append(names[i]).append("\""); }
        sb.append("],\"monthlyPct\":[");
        for (int m=1;m<=12;m++){ if(m>1) sb.append(","); sb.append(monthly.getOrDefault(m,0.0)); }
        sb.append("]}");
        out.print(sb.toString());
    }

    private int singleInt(Connection con, String sql) throws SQLException {
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }
    private String esc(String s){ return s==null ? "" : s.replace("\\","\\\\").replace("\"","\\\""); }
}