package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import dbutil.DBConnection;

public class TeacherListClassesDetailedServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        resp.setHeader("Cache-Control", "no-store");
        PrintWriter out = resp.getWriter();

        HttpSession ses = req.getSession(false);
        if (ses == null || !"teacher".equals(ses.getAttribute("role"))) {
            resp.setStatus(401); out.print("{\"unauthorized\":true}"); return;
        }
        int teacherId = (int) ses.getAttribute("teacherId");

        String sql = "SELECT c.class_id AS id, c.class_name AS name, " +
                " (SELECT COUNT(*) FROM student s WHERE s.class_id=c.class_id) AS students " +
                "FROM classroom c WHERE c.teacher_id=? ORDER BY c.class_id";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, teacherId);
            ResultSet rs = ps.executeQuery();
            StringBuilder sb = new StringBuilder("[");
            boolean first = true;
            while (rs.next()) {
                if(!first) sb.append(",");
                sb.append("{\"id\":").append(rs.getInt("id"))
                        .append(",\"name\":\"").append(esc(rs.getString("name"))).append("\"")
                        .append(",\"students\":").append(rs.getInt("students")).append("}");
                first=false;
            }
            sb.append("]");
            out.print(sb.toString());
        } catch (SQLException e) {
            out.print("{\"error\":\""+esc(e.getMessage())+"\"}");
        }
    }
    private String esc(String s){ return s==null ? "" : s.replace("\"","\\\""); }
}