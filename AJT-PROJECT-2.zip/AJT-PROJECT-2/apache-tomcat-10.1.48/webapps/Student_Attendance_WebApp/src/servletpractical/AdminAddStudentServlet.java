package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import dbutil.DBConnection;

public class AdminAddStudentServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        resp.setHeader("Cache-Control", "no-store");
        PrintWriter out = resp.getWriter();

        String name = req.getParameter("name");
        String roll = req.getParameter("roll");
        String classIdStr = req.getParameter("classId");
        String pass = req.getParameter("pass");

        if (name == null || roll == null || classIdStr == null || pass == null ||
                name.isBlank() || roll.isBlank() || classIdStr.isBlank() || pass.isBlank()) {
            out.print("{\"ok\":false,\"msg\":\"Missing fields\"}");
            return;
        }

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "INSERT INTO student(name, roll_no, class_id, password) VALUES(?,?,?,?)",
                     Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, name);
            ps.setString(2, roll);
            ps.setInt(3, Integer.parseInt(classIdStr));
            ps.setString(4, pass);
            int rows = ps.executeUpdate();

            if (rows > 0) {
                ResultSet keys = ps.getGeneratedKeys();
                int id = keys.next() ? keys.getInt(1) : 0;
                out.print("{\"ok\":true,\"id\":"+id+"}");
            } else {
                out.print("{\"ok\":false,\"msg\":\"Insert failed\"}");
            }
        } catch (SQLException e) {
            out.print("{\"ok\":false,\"msg\":\"" + e.getMessage().replace("\"","\\\"") + "\"}");
        }
    }
}