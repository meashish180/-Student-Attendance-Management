package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import dbutil.DBConnection;

public class StudentAttendanceRangeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setHeader("Cache-Control", "no-store");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("student_id") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("{\"error\":\"Not logged in\"}");
            return;
        }

        int studentId = (int) session.getAttribute("student_id");
        String subjectId = request.getParameter("subjectId");
        String fromDate = request.getParameter("from");
        String toDate = request.getParameter("to");

        // Build query dynamically depending on filters
        StringBuilder sql = new StringBuilder(
                "SELECT a.date, a.status, s.subject_name " +
                        "FROM attendance a JOIN subject s ON a.subject_id = s.subject_id " +
                        "WHERE a.student_id = ?");
        if (subjectId != null && !subjectId.isEmpty())
            sql.append(" AND a.subject_id = ?");
        if (fromDate != null && !fromDate.isEmpty())
            sql.append(" AND a.date >= ?");
        if (toDate != null && !toDate.isEmpty())
            sql.append(" AND a.date <= ?");
        sql.append(" ORDER BY a.date");

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {

            int index = 1;
            ps.setInt(index++, studentId);
            if (subjectId != null && !subjectId.isEmpty())
                ps.setInt(index++, Integer.parseInt(subjectId));
            if (fromDate != null && !fromDate.isEmpty())
                ps.setString(index++, fromDate);
            if (toDate != null && !toDate.isEmpty())
                ps.setString(index++, toDate);

            int present = 0, total = 0;
            StringBuilder rowsJson = new StringBuilder("[");

            try (ResultSet rs = ps.executeQuery()) {
                boolean first = true;
                while (rs.next()) {
                    if (!first) rowsJson.append(",");
                    first = false;
                    String date = rs.getString("date");
                    String status = rs.getString("status");
                    String subject = rs.getString("subject_name");

                    if ("P".equalsIgnoreCase(status)) present++;
                    total++;

                    rowsJson.append("{")
                            .append("\"date\":\"").append(date).append("\",")
                            .append("\"subject\":\"").append(escape(subject)).append("\",")
                            .append("\"status\":\"").append(status).append("\"")
                            .append("}");
                }
            }
            rowsJson.append("]");

            double pct = (total > 0) ? (present * 100.0 / total) : 0.0;

            out.println("{");
            out.println("\"present\": " + present + ",");
            out.println("\"total\": " + total + ",");
            out.println("\"percent\": " + String.format("%.2f", pct) + ",");
            out.println("\"rows\": " + rowsJson);
            out.println("}");

        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\":\"Database error: " + escape(e.getMessage()) + "\"}");
        }
    }

    private String escape(String s) {
        return s == null ? "" : s.replace("\"", "\\\"");
    }
}