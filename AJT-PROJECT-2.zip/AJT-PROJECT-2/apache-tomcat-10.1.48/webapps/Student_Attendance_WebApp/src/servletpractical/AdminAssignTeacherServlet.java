package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import dbutil.DBConnection;

public class AdminAssignTeacherServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        resp.setHeader("Cache-Control", "no-store");
        PrintWriter out = resp.getWriter();



        String classIdStr = req.getParameter("classId");
        String teacherIdStr = req.getParameter("teacherId");

        if (classIdStr == null || classIdStr.isBlank() || teacherIdStr == null || teacherIdStr.isBlank()) {
            out.print("{\"ok\":false,\"msg\":\"Missing classId or teacherId\"}");
            return;
        }

        int classId, teacherId;
        try {
            classId = Integer.parseInt(classIdStr.trim());
            teacherId = Integer.parseInt(teacherIdStr.trim());
        } catch (NumberFormatException nfe) {
            out.print("{\"ok\":false,\"msg\":\"classId/teacherId must be integers\"}");
            return;
        }

        try (Connection con = DBConnection.getConnection()) {

            // 1) verify class exists
            boolean classExists = false;
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT 1 FROM classroom WHERE class_id=?")) {
                ps.setInt(1, classId);
                try (ResultSet rs = ps.executeQuery()) {
                    classExists = rs.next();
                }
            }
            if (!classExists) {
                out.print("{\"ok\":false,\"msg\":\"Class not found\"}");
                return;
            }

            // 2) verify teacher exists
            boolean teacherExists = false;
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT 1 FROM teacher WHERE teacher_id=?")) {
                ps.setInt(1, teacherId);
                try (ResultSet rs = ps.executeQuery()) {
                    teacherExists = rs.next();
                }
            }
            if (!teacherExists) {
                out.print("{\"ok\":false,\"msg\":\"Teacher not found\"}");
                return;
            }

            // 3) assign
            int rows;
            try (PreparedStatement ps = con.prepareStatement(
                    "UPDATE classroom SET teacher_id=? WHERE class_id=?")) {
                ps.setInt(1, teacherId);
                ps.setInt(2, classId);
                rows = ps.executeUpdate();
            }

            if (rows > 0) {
                out.print("{\"ok\":true}");
            } else {
                out.print("{\"ok\":false,\"msg\":\"Update failed\"}");
            }

        } catch (SQLException e) {
            out.print("{\"ok\":false,\"msg\":\"" + e.getMessage().replace("\"","\\\"") + "\"}");
        }
    }
}