package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import dbutil.DBConnection;
import java.util.*;

public class StudentSubjectBreakdownServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setHeader("Cache-Control", "no-store");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("student_id") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.println("{\"error\":\"Not logged in\"}");
            return;
        }

        int studentId = (int) session.getAttribute("student_id");

        try (Connection con = DBConnection.getConnection()) {

            // get class_id for that student
            int classId = 0;
            try (PreparedStatement ps = con.prepareStatement("SELECT class_id FROM student WHERE student_id=?")) {
                ps.setInt(1, studentId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) classId = rs.getInt("class_id");
                }
            }

            // fetch all subjects for this class
            List<Map<String,Object>> list = new ArrayList<>();
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT subject_id, subject_name FROM subject WHERE class_id=?")) {
                ps.setInt(1, classId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        int subjId = rs.getInt("subject_id");
                        String subjName = rs.getString("subject_name");

                        // compute attendance for each subject
                        int present = 0, total = 0;
                        try (PreparedStatement ps2 = con.prepareStatement(
                                "SELECT SUM(status='P') AS present, COUNT(*) AS total " +
                                        "FROM attendance WHERE student_id=? AND subject_id=?")) {
                            ps2.setInt(1, studentId);
                            ps2.setInt(2, subjId);
                            try (ResultSet rs2 = ps2.executeQuery()) {
                                if (rs2.next()) {
                                    present = rs2.getInt("present");
                                    total = rs2.getInt("total");
                                }
                            }
                        }
                        double pct = (total>0) ? (present*100.0/total) : 0.0;

                        Map<String,Object> row = new LinkedHashMap<>();
                        row.put("id", subjId);
                        row.put("name", subjName);
                        row.put("present", present);
                        row.put("total", total);
                        row.put("percent", String.format("%.2f", pct));
                        list.add(row);
                    }
                }
            }

            // output JSON manually
            out.print("[");
            for (int i=0; i<list.size(); i++) {
                Map<String,Object> r = list.get(i);
                if (i>0) out.print(",");
                out.print("{");
                out.print("\"id\":" + r.get("id") + ",");
                out.print("\"name\":\"" + escape((String)r.get("name")) + "\",");
                out.print("\"present\":" + r.get("present") + ",");
                out.print("\"total\":" + r.get("total") + ",");
                out.print("\"percent\":" + r.get("percent"));
                out.print("}");
            }
            out.print("]");

        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.println("{\"error\":\"DB error: " + escape(e.getMessage()) + "\"}");
        }
    }

    private String escape(String s){
        return (s==null) ? "" : s.replace("\"","\\\"");
    }
}