package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import dbutil.DBConnection;

public class AdminDeleteTeacherServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        resp.setHeader("Cache-Control", "no-store");
        PrintWriter out = resp.getWriter();

        String idStr = req.getParameter("id");
        if (idStr == null || idStr.isBlank()) {
            out.print("{\"ok\":false,\"msg\":\"Missing id\"}");
            return;
        }

        int teacherId;
        try {
            teacherId = Integer.parseInt(idStr.trim());
        } catch (NumberFormatException e) {
            out.print("{\"ok\":false,\"msg\":\"Invalid id\"}");
            return;
        }

        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);

            // 1) Check teacher exists
            try (PreparedStatement ps = con.prepareStatement("SELECT 1 FROM teacher WHERE teacher_id=?")) {
                ps.setInt(1, teacherId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        con.rollback();
                        out.print("{\"ok\":false,\"msg\":\"Teacher not found\"}");
                        return;
                    }
                }
            }

            // 2) Unassign classes that reference this teacher
            int unassigned = 0;
            try (PreparedStatement ps = con.prepareStatement(
                    "UPDATE classroom SET teacher_id = NULL WHERE teacher_id=?")) {
                ps.setInt(1, teacherId);
                unassigned = ps.executeUpdate();
            }

            // 3) Delete the teacher
            int deleted = 0;
            try (PreparedStatement ps = con.prepareStatement(
                    "DELETE FROM teacher WHERE teacher_id=?")) {
                ps.setInt(1, teacherId);
                deleted = ps.executeUpdate();
            }

            con.commit();
            if (deleted > 0) {
                out.print("{\"ok\":true,\"unassigned\":" + unassigned + "}");
            } else {
                out.print("{\"ok\":false,\"msg\":\"Delete failed\"}");
            }
        } catch (SQLException e) {
            out.print("{\"ok\":false,\"msg\":\"" + e.getMessage().replace("\"","\\\"") + "\"}");
        }
    }
}