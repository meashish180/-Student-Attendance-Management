package servletpractical;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import dbutil.DBConnection;

public class AdminListTeachersServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT teacher_id,name,email,department FROM teacher ORDER BY teacher_id DESC")) {
            ResultSet rs = ps.executeQuery();

            StringBuilder sb = new StringBuilder();
            sb.append("[");
            boolean first = true;
            while (rs.next()) {
                if (!first) sb.append(",");
                sb.append("{");
                sb.append("\"id\":").append(rs.getInt("teacher_id")).append(",");
                sb.append("\"name\":\"").append(esc(rs.getString("name"))).append("\",");
                sb.append("\"email\":\"").append(esc(rs.getString("email"))).append("\",");
                sb.append("\"department\":\"").append(esc(rs.getString("department"))).append("\"");
                sb.append("}");
                first = false;
            }
            sb.append("]");
            out.print(sb.toString());
        } catch (SQLException e) {
            out.print("{\"error\":\"" + esc(e.getMessage()) + "\"}");
        }
    }
    private String esc(String s){ return s==null ? "" : s.replace("\"","\\\""); }
}