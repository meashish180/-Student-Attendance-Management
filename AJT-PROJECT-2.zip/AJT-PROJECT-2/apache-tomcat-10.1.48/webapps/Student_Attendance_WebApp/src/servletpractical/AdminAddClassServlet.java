package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import dbutil.DBConnection;

public class AdminAddClassServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        resp.setHeader("Cache-Control", "no-store");
        PrintWriter out = resp.getWriter();

        String className = req.getParameter("className");
        String teacherId = req.getParameter("teacherId"); // optional

        if (className == null || className.isBlank()) {
            out.print("{\"ok\":false,\"msg\":\"Missing className\"}");
            return;
        }

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "INSERT INTO classroom (class_name, teacher_id) VALUES (?,?)",
                     Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, className.trim());
            if (teacherId == null || teacherId.isBlank()) {
                ps.setNull(2, Types.INTEGER);
            } else {
                ps.setInt(2, Integer.parseInt(teacherId));
            }

            int rows = ps.executeUpdate();
            if (rows > 0) {
                ResultSet keys = ps.getGeneratedKeys();
                int id = keys.next() ? keys.getInt(1) : 0;
                out.print("{\"ok\":true,\"id\":"+id+"}");
            } else {
                out.print("{\"ok\":false,\"msg\":\"Insert failed\"}");
            }
        } catch (SQLException e) {
            out.print("{\"ok\":false,\"msg\":\""+e.getMessage().replace("\"","\\\"")+"\"}");
        }
    }
}