package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import dbutil.DBConnection;

public class AdminClassStatsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        resp.setHeader("Cache-Control", "no-store");
        PrintWriter out = resp.getWriter();

        String classId = req.getParameter("classId");
        if (classId == null || classId.isBlank()) { out.print("{\"error\":\"Missing classId\"}"); return; }

        String className = "", teacherName = "";
        int students = 0, subjects = 0, pToday = 0, tToday = 0;
        Map<Integer, Double> monthly = new HashMap<>();

        try (Connection con = DBConnection.getConnection()) {
            // class + teacher
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT c.class_name, t.name FROM classroom c LEFT JOIN teacher t ON t.teacher_id=c.teacher_id WHERE c.class_id=?")) {
                ps.setInt(1, Integer.parseInt(classId));
                ResultSet rs = ps.executeQuery();
                if (rs.next()) { className = n(rs.getString(1)); teacherName = n(rs.getString(2)); }
            }

            // students
            students = singleInt(con, "SELECT COUNT(*) FROM student WHERE class_id="+classId);

            // subjects
            subjects = singleInt(con, "SELECT COUNT(*) FROM subject WHERE class_id="+classId);

            // today's P/A for this class
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT SUM(CASE WHEN a.status='P' THEN 1 ELSE 0 END) AS p, COUNT(*) AS t " +
                            "FROM attendance a JOIN subject s ON a.subject_id=s.subject_id " +
                            "WHERE s.class_id=? AND a.date=CURDATE()")) {
                ps.setInt(1, Integer.parseInt(classId));
                ResultSet rs = ps.executeQuery();
                if (rs.next()) { pToday = rs.getInt("p"); tToday = rs.getInt("t"); }
            }

            // monthly trend for this class
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT MONTH(a.date) AS m, " +
                            "ROUND(SUM(CASE WHEN a.status='P' THEN 1 ELSE 0 END)/COUNT(*)*100,2) AS pct " +
                            "FROM attendance a JOIN subject s ON a.subject_id=s.subject_id " +
                            "WHERE s.class_id=? AND YEAR(a.date)=YEAR(CURDATE()) " +
                            "GROUP BY MONTH(a.date)")) {
                ps.setInt(1, Integer.parseInt(classId));
                ResultSet rs = ps.executeQuery();
                while (rs.next()) monthly.put(rs.getInt("m"), rs.getDouble("pct"));
            }
        } catch (SQLException e) {
            out.print("{\"error\":\""+esc(e.getMessage())+"\"}");
            return;
        }

        String[] names = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
        double pctToday = (tToday>0)? Math.round((pToday*10000.0/tToday))/100.0 : 0.0;

        StringBuilder sb = new StringBuilder();
        sb.append("{")
                .append("\"className\":\"").append(esc(className)).append("\",")
                .append("\"teacherName\":\"").append(esc(teacherName)).append("\",")
                .append("\"students\":").append(students).append(",")
                .append("\"subjects\":").append(subjects).append(",")
                .append("\"today\":{")
                .append("\"present\":").append(pToday).append(",\"total\":").append(tToday)
                .append(",\"percent\":").append(pctToday).append("},")
                .append("\"months\":[");
        for (int i=0;i<12;i++){ if(i>0) sb.append(","); sb.append("\"").append(names[i]).append("\""); }
        sb.append("],\"monthlyPct\":[");
        for (int m=1;m<=12;m++){ if(m>1) sb.append(","); sb.append(monthly.getOrDefault(m,0.0)); }
        sb.append("]}");
        out.print(sb.toString());
    }

    private int singleInt(Connection con, String sql) throws SQLException {
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }
    private String n(String s){ return s==null ? "" : s; }
    private String esc(String s){ return s==null ? "" : s.replace("\\","\\\\").replace("\"","\\\""); }
}