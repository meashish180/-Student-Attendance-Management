package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import dbutil.DBConnection;

public class AdminListStudentsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        resp.setHeader("Cache-Control", "no-store");
        PrintWriter out = resp.getWriter();



        String q = req.getParameter("q");
        boolean hasQ = q != null && !q.isBlank();

        String sqlBase =
                "SELECT s.student_id AS id, s.name, s.roll_no AS roll, s.class_id AS classId, c.class_name AS className " +
                        "FROM student s LEFT JOIN classroom c ON s.class_id = c.class_id ";
        String sqlAll = sqlBase + "ORDER BY s.student_id DESC";
        String sqlQ   = sqlBase +
                "WHERE s.name LIKE ? OR s.roll_no LIKE ? OR c.class_name LIKE ? " +
                "ORDER BY s.student_id DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(hasQ ? sqlQ : sqlAll)) {

            if (hasQ) {
                String like = "%" + q.trim() + "%";
                ps.setString(1, like);
                ps.setString(2, like);
                ps.setString(3, like);
            }
            ResultSet rs = ps.executeQuery();

            StringBuilder sb = new StringBuilder();
            sb.append("[");
            boolean first = true;
            while (rs.next()) {
                if (!first) sb.append(",");
                sb.append("{");
                sb.append("\"id\":").append(rs.getInt("id")).append(",");
                sb.append("\"name\":\"").append(esc(rs.getString("name"))).append("\",");
                sb.append("\"roll\":\"").append(esc(rs.getString("roll"))).append("\",");
                sb.append("\"classId\":").append(rs.getInt("classId")).append(",");
                String cn = rs.getString("className");
                sb.append("\"className\":\"").append(esc(cn)).append("\"");
                sb.append("}");
                first = false;
            }
            sb.append("]");
            out.print(sb.toString());

        } catch (SQLException e) {
            // Return the error so you can see it in DevTools → Network
            out.print("{\"error\":\"" + esc(e.getMessage()) + "\"}");
        }
    }

    private String esc(String s) {
        return s == null ? "" : s.replace("\\", "\\\\").replace("\"","\\\"");
    }
}