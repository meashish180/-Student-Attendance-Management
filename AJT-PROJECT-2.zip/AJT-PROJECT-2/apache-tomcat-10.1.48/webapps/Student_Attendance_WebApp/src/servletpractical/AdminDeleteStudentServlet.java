package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import dbutil.DBConnection;

public class AdminDeleteStudentServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        resp.setHeader("Cache-Control", "no-store");
        PrintWriter out = resp.getWriter();

        String idStr = req.getParameter("id");
        if (idStr == null || idStr.isBlank()) {
            out.print("{\"ok\":false,\"msg\":\"Missing id\"}");
            return;
        }

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement("DELETE FROM student WHERE student_id=?")) {
            ps.setInt(1, Integer.parseInt(idStr));
            int rows = ps.executeUpdate();
            if (rows > 0) out.print("{\"ok\":true}");
            else out.print("{\"ok\":false,\"msg\":\"Not found\"}");
        } catch (SQLException e) {
            out.print("{\"ok\":false,\"msg\":\""+e.getMessage().replace("\"","\\\"")+"\"}");
        }
    }
}