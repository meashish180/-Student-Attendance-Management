package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import dbutil.DBConnection;

public class TeacherLoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String user = request.getParameter("username"); // email
        String pass = request.getParameter("password");

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT teacher_id, name, email FROM teacher WHERE email=? AND password=?")) {

            ps.setString(1, user);
            ps.setString(2, pass);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                HttpSession session = request.getSession();
                session.setAttribute("role", "teacher");
                session.setAttribute("teacherId", rs.getInt("teacher_id"));
                session.setAttribute("teacherName", rs.getString("name"));
                session.setAttribute("teacherEmail", rs.getString("email"));

                // Optional: also set localStorage name via JS then redirect
                out.println("<script>localStorage.setItem('sas_teacher_name', '"+rs.getString("name").replace("'", "\\'")+"');"
                        + "location='teacher_dashboard.html';</script>");
            } else {
                out.println("<script>alert('Invalid Email or Password');window.location='teacher_login.html';</script>");
            }

        } catch (SQLException e) {
            out.println("<h3>Database error: " + e.getMessage() + "</h3>");
        }
    }
}