package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import dbutil.DBConnection;

public class SaveAttendanceServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        resp.setHeader("Cache-Control", "no-store");
        PrintWriter out = resp.getWriter();

        HttpSession ses = req.getSession(false);
        if (ses == null || !"teacher".equals(ses.getAttribute("role"))) {
            resp.setStatus(401);
            out.print("{\"unauthorized\":true}");
            return;
        }

        String classId  = req.getParameter("classId");
        String subjectId = req.getParameter("subjectId");
        String dateStr  = req.getParameter("date");
        String present  = req.getParameter("presentIds");

        if (classId==null || subjectId==null || dateStr==null ||
                classId.isBlank() || subjectId.isBlank() || dateStr.isBlank()) {
            out.print("{\"ok\":false,\"msg\":\"Missing classId/subjectId/date\"}");
            return;
        }

        Set<Integer> presentSet = new HashSet<>();
        if (present != null && !present.isBlank()) {
            for (String s : present.split(",")) {
                try { presentSet.add(Integer.parseInt(s.trim())); } catch (NumberFormatException ignore) {}
            }
        }

        int saved = 0;
        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);

            // roster
            List<Integer> sids = new ArrayList<>();
            try (PreparedStatement ps = con.prepareStatement("SELECT student_id FROM student WHERE class_id=?")) {
                ps.setInt(1, Integer.parseInt(classId));
                ResultSet rs = ps.executeQuery();
                while (rs.next()) sids.add(rs.getInt(1));
            }

            if (sids.isEmpty()) { con.rollback(); out.print("{\"ok\":false,\"msg\":\"No students in class\"}"); return; }

            // insert/update
            String sql = "INSERT INTO attendance (student_id, subject_id, date, status) " +
                    "VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE status=VALUES(status)";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                java.sql.Date d = java.sql.Date.valueOf(dateStr);
                int subj = Integer.parseInt(subjectId);
                for (int sid : sids) {
                    ps.setInt(1, sid);
                    ps.setInt(2, subj);
                    ps.setDate(3, d);
                    ps.setString(4, presentSet.contains(sid) ? "P" : "A");
                    ps.addBatch();
                }
                int[] res = ps.executeBatch();
                for (int r : res) if (r >= 0) saved++;
            }

            con.commit();
            out.print("{\"ok\":true,\"saved\":"+saved+"}");
        } catch (SQLException e) {
            out.print("{\"ok\":false,\"msg\":\""+e.getMessage().replace("\"","\\\"")+"\"}");
        }
    }
}