package servletpractical;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import dbutil.DBConnection;

public class AdminListClassesDetailedServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        resp.setHeader("Cache-Control", "no-store");
        PrintWriter out = resp.getWriter();

        String sql =
                "SELECT c.class_id AS id, c.class_name AS className, t.name AS teacherName, " +
                        " (SELECT COUNT(*) FROM student s WHERE s.class_id=c.class_id) AS studentsCount " +
                        "FROM classroom c LEFT JOIN teacher t ON t.teacher_id=c.teacher_id " +
                        "ORDER BY c.class_id DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            StringBuilder sb = new StringBuilder("[");
            boolean first = true;
            while (rs.next()) {
                if (!first) sb.append(",");
                sb.append("{\"id\":").append(rs.getInt("id"))
                        .append(",\"className\":\"").append(esc(rs.getString("className"))).append("\"")
                        .append(",\"teacherName\":\"").append(esc(rs.getString("teacherName"))).append("\"")
                        .append(",\"studentsCount\":").append(rs.getInt("studentsCount")).append("}");
                first = false;
            }
            sb.append("]");
            out.print(sb.toString());
        } catch (SQLException e) {
            out.print("{\"error\":\""+esc(e.getMessage())+"\"}");
        }
    }
    private String esc(String s){ return s==null? "" : s.replace("\"","\\\""); }
}